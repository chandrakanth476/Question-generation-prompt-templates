# generator.py
from typing import List, Optional, Dict, Set
import random
from templates import (
    base_question_template,
    context_aware_template,
    difficulty_control_template,
    topic_variation_template,
    normalize_difficulty,
)
from utils import SUPPORTED_DOMAINS, normalize_domain, load_state, save_state

class QuestionGenerator:
    def __init__(self, persist: bool = True):
        self.persist = persist
        self.generated: Set[str] = load_state() if persist else set()

    def _choose_topic(self, domain: str, excluded: Optional[List[str]] = None) -> str:
        topics = SUPPORTED_DOMAINS.get(domain, SUPPORTED_DOMAINS["dsa"])
        choices = [t for t in topics if not excluded or t not in excluded]
        if not choices:
            choices = topics
        return random.choice(choices)

    def _already_generated(self, text: str) -> bool:
        return text in self.generated

    def _mark_generated(self, text: str) -> None:
        self.generated.add(text)
        if self.persist:
            save_state(self.generated)

    def generate(self,
                 domain: Optional[str],
                 difficulty: Optional[str],
                 template_type: str = "base",
                 num: int = 1,
                 context: Optional[Dict] = None,
                 excluded_topics: Optional[List[str]] = None) -> List[Dict]:
        domain_norm = normalize_domain(domain)
        results = []
        attempts = 0
        max_attempts = num * 8

        while len(results) < num and attempts < max_attempts:
            attempts += 1
            topic = self._choose_topic(domain_norm, excluded_topics)
            diff = normalize_difficulty(difficulty)
            if template_type == "base":
                item = base_question_template(domain_norm, topic, diff)
            elif template_type == "context":
                prev_q = (context or {}).get("prev_question", "")
                cand_ans = (context or {}).get("candidate_answer", "")
                item = context_aware_template(prev_q, cand_ans, domain_norm, topic, diff)
            elif template_type == "difficulty":
                item = difficulty_control_template(domain_norm, topic, diff)
            elif template_type == "variation":
                avoid = excluded_topics or []
                item = topic_variation_template(domain_norm, topic, diff, avoid)
            else:
                # fallback to base
                item = base_question_template(domain_norm, topic, diff)

            qtext = item["question"]
            # basic constraint enforcement
            if self._already_generated(qtext):
                continue
            # simple domain check: ensure domain substring in qtext
            if domain_norm not in qtext.lower():
                # fallback: attach domain label
                item["question"] = f"[{domain_norm}] {item['question']}"
            self._mark_generated(item["question"])
            results.append(item)

        return results