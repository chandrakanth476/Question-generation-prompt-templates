# run.py
import argparse
import json
from generator import QuestionGenerator

def main():
    parser = argparse.ArgumentParser(description="Question generator CLI")
    parser.add_argument("--domain", type=str, default="DSA")
    parser.add_argument("--difficulty", type=str, default="medium")
    parser.add_argument("--template", type=str, default="base",
                        choices=["base", "context", "difficulty", "variation"])
    parser.add_argument("--num", type=int, default=3)
    parser.add_argument("--prev_question", type=str, default="")
    parser.add_argument("--candidate_answer", type=str, default="")
    parser.add_argument("--exclude", type=str, default="")
    parser.add_argument("--no_persist", action="store_true")
    parser.add_argument("--out", type=str, default="")
    args = parser.parse_args()

    context = None
    if args.template == "context":
        context = {"prev_question": args.prev_question, "candidate_answer": args.candidate_answer}
    excluded = [s.strip() for s in args.exclude.split(",")] if args.exclude else None

    gen = QuestionGenerator(persist=not args.no_persist)
    results = gen.generate(args.domain, args.difficulty, template_type=args.template,
                           num=args.num, context=context, excluded_topics=excluded)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        print(f"Wrote {len(results)} items to {args.out}")
    else:
        print(json.dumps(results, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()