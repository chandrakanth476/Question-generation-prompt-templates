# utils.py
from typing import Optional, Set, List
import json
import os

SUPPORTED_DOMAINS = {
    "dsa": ["arrays", "linked list", "binary tree", "graph", "dynamic programming", "sorting", "search"],
    "system design": ["load balancing", "caching", "database sharding", "messaging", "consistency", "api gateway"],
    "algorithms": ["greedy", "divide and conquer", "dp", "graph", "sorting"],
}

DEFAULT_DOMAIN = "dsa"
DEFAULT_DIFFICULTY = "medium"
STATE_FILENAME = "output_state.json"

def normalize_domain(domain: Optional[str]) -> str:
    if not domain:
        return DEFAULT_DOMAIN
    d = domain.strip().lower()
    if d in SUPPORTED_DOMAINS:
        return d
    # try simple mapping
    if "data" in d or "dsa" in d:
        return "dsa"
    if "system" in d or "design" in d:
        return "system design"
    if "algo" in d:
        return "algorithms"
    return DEFAULT_DOMAIN

# Simple persistent store for generated questions across runs (file-based)
def load_state(filename: str = STATE_FILENAME) -> Set[str]:
    if not os.path.exists(filename):
        return set()
    try:
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)
            return set(data.get("generated_questions", []))
    except Exception:
        return set()

def save_state(generated: Set[str], filename: str = STATE_FILENAME) -> None:
    data = {"generated_questions": list(generated)}
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)