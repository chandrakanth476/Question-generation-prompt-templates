# tests/test_generator.py
import os
import tempfile
from generator import QuestionGenerator
from utils import DEFAULT_DOMAIN

def test_generate_no_repeat(tmp_path):
    # make sure persistence file is isolated for test
    state_file = tmp_path / "state.json"
    # monkeypatch utils.STATE_FILENAME if needed, but here use no persist
    gen = QuestionGenerator(persist=False)
    res1 = gen.generate("DSA", "easy", num=2)
    res2 = gen.generate("DSA", "easy", num=2)
    # Because persist=False, repeated generation across instances can repeat but within one instance should not repeat
    texts = [r['question'] for r in res1]
    assert len(texts) == len(set(texts))

def test_domain_fallback():
    gen = QuestionGenerator(persist=False)
    res = gen.generate("unknown domain name", "medium", num=1)
    # Unknown domain should fallback to DEFAULT_DOMAIN
    assert DEFAULT_DOMAIN in res[0]['question'].lower()
