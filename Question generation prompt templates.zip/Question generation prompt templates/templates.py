# templates.py
from typing import Optional, List, Dict

def normalize_difficulty(difficulty: Optional[str]) -> str:
    if not difficulty:
        return "medium"
    d = difficulty.lower().strip()
    if d in ("easy", "e"):
        return "easy"
    if d in ("medium", "m", "moderate"):
        return "medium"
    if d in ("hard", "h", "difficult"):
        return "hard"
    return "medium"

# Basic templates produce final question text and a small metadata dict.
def base_question_template(domain: str, topic: str, difficulty: str) -> Dict:
    diff = normalize_difficulty(difficulty)
    if diff == "easy":
        prompt_style = "conceptual"
    elif diff == "medium":
        prompt_style = "applied"
    else:
        prompt_style = "problem-solving"

    question_text = f"[{domain}] ({diff}) {topic}: "
    if prompt_style == "conceptual":
        question_text += f"Explain the core concept of {topic} and give one simple example."
    elif prompt_style == "applied":
        question_text += f"Design or implement a solution for {topic} in a typical interview scenario. Describe approach and complexity."
    else:
        question_text += (
            f"Present a challenging problem about {topic} that requires multiple steps to solve. "
            "Provide input/output examples and explain the steps."
        )

    return {
        "question": question_text,
        "topic": topic,
        "difficulty": diff,
        "style": prompt_style,
    }

def context_aware_template(prev_question: str,
                           candidate_answer: Optional[str],
                           domain: str,
                           topic: str,
                           difficulty: str) -> Dict:
    base = base_question_template(domain, topic, difficulty)
    context_note = ""
    if prev_question:
        context_note += f"Follow-up to: \"{prev_question}\". "
    if candidate_answer:
        context_note += f"Candidate answered: \"{candidate_answer}\". Provide feedback and a next question."
    else:
        context_note += "Provide a follow-up question that probes deeper."

    base["question"] = f"{base['question']} (Context: {context_note})"
    base["context"] = {"prev_question": prev_question, "candidate_answer": candidate_answer}
    return base

def difficulty_control_template(domain: str, topic: str, difficulty: str) -> Dict:
    # Explicitly enforce type of question based on difficulty
    diff = normalize_difficulty(difficulty)
    if diff == "easy":
        instruction = "Keep it conceptual and short; do not ask for code."
    elif diff == "medium":
        instruction = "Ask for an applied solution; allow a short code sketch or pseudocode and complexity analysis."
    else:
        instruction = "Ask a complex problem requiring multi-step reasoning and algorithmic design; include edge cases."

    base = base_question_template(domain, topic, diff)
    base["question"] = f"{base['question']} (Difficulty control: {instruction})"
    base["difficulty_instruction"] = instruction
    return base

def topic_variation_template(domain: str, topic: str, difficulty: str, ensure_variation: List[str]) -> Dict:
    # ensure_variation: list of topics to avoid repeating
    base = base_question_template(domain, topic, difficulty)
    base["topic_variation"] = {"avoid": ensure_variation}
    return base